4
3
7
2
4
=
54


2
3
4
=
10

2
a
4
=
error

2
-4
5
=
64 returns 97 as it does not handle the -4^2
